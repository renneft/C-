/* SPDX-License-Identifier: MIT. Units: bar, day, metre, surface m3/day. */
function createSimulator() {
  'use strict';
  const defaults={k:50,phi:15,pi:150,h:30,cr:0.00005,cf:0,mu:1,B:1.3,rw:0.1,R:500,L:300,q:50,pwf:50,days:366,quality:1};
  const names={closed:'Круг: непроницаемый контур',fixed:'Круг: постоянное давление',infinite:'Бесконечный пласт',strip:'Две параллельные границы',half:'Одна непроницаемая граница'};
  function validate(p){
    for(const k of Object.keys(defaults))if(!Number.isFinite(p[k]))throw Error('Некорректное число: '+k);
    for(const k of ['k','phi','pi','h','mu','B','rw','R','L','q','days'])if(p[k]<=0)throw Error('Параметр '+k+' должен быть положительным.');
    if(p.phi>=100||p.cr<0||p.cf<0||p.cr+p.cf<=0)throw Error('Пористость должна быть меньше 100%, сжимаемости — неотрицательными, их сумма — положительной.');
    if(p.pwf<=0||p.pwf>=p.pi)throw Error('Забойное давление должно быть между 0 и начальным пластовым давлением.');
    if(p.R<=100*p.rw||p.L<=100*p.rw)throw Error('Радиус контура и расстояние до границы должны превышать 100 радиусов скважины.');
    if(p.days>10000||p.days<0.01)throw Error('Период расчёта: от 0,01 до 10 000 суток.');
    if(![0,1,2].includes(p.quality))throw Error('Неизвестный уровень сетки.');
    const a=derived(p);if(!Number.isFinite(a.alpha)||a.alpha*p.days>1e16||a.alpha*p.days<1e-8)throw Error('Сочетание параметров выходит за поддерживаемый диапазон диффузии.');
  }
  function derived(p){const mobility=p.k*9.869233e-16/(p.mu*.001)*86400*1e5;return {mobility,alpha:mobility/(p.phi/100*(p.cr+p.cf)),C:p.B/(2*Math.PI*mobility*p.h)};}
  function times(p,mult=1){const n=Math.round([150,230,340][p.quality]*mult),t0=Math.min(.001,p.days/10000),t=[0];for(let i=0;i<=n;i++)t.push(t0*Math.pow(p.days/t0,i/n));return t;}
  function grid(p,kind){
    const {mobility,alpha,C}=derived(p),cap=[],ei=[],ej=[],eg=[],out=[],base=[];
    let well=0,wi,domain,shape;
    const edge=(i,j,g)=>{ei.push(i);ej.push(j);eg.push(g);base[i]+=g;base[j]+=g;};
    if(kind==='closed'||kind==='fixed'){
      const n=[60,100,170][p.quality],r=[],e=[];for(let i=0;i<=n;i++)e.push(p.rw*Math.pow(p.R/p.rw,i/n));
      for(let i=0;i<n;i++){r.push(Math.sqrt(e[i]*e[i+1]));cap.push(p.phi/100*(p.cr+p.cf)*Math.PI*(e[i+1]**2-e[i]**2)*p.h/p.B);base.push(0);out.push(0);}
      for(let i=0;i<n-1;i++)edge(i,i+1,1/(C*Math.log(r[i+1]/r[i])));
      wi=1/(C*Math.log(r[0]/p.rw));if(kind==='fixed'){out[n-1]=1/(C*Math.log(p.R/r[n-1]));base[n-1]+=out[n-1];}
      domain=p.R;shape=`${n} радиальных ячеек`;
    }else{
      // Distant Dirichlet boundaries approximate infinity. exp(-D²/(4 alpha T)) <= exp(-16).
      domain=Math.max(8*Math.sqrt(alpha*p.days),10*p.L,1000*p.rw);
      const a=5*p.rw,n=[23,33,47][p.quality];
      // Keep a uniform collar around the well for the Peaceman well index.
      // Outside four cells in each direction, grow cell widths geometrically.
      function side(extent){const e=[a],s=2*a;for(let i=0;i<4;i++)e.push(e.at(-1)+s);const count=n-4,remaining=extent-e.at(-1);let lo=0,hi=4;const total=r=>{let v=0;for(let j=1;j<=count;j++)v+=s*Math.pow(r,j);return v;};while(total(hi)<remaining)hi*=2;for(let j=0;j<80;j++){const mid=(lo+hi)/2;if(total(mid)<remaining)lo=mid;else hi=mid;}const ratio=(lo+hi)/2;for(let j=1;j<=count;j++)e.push(e.at(-1)+s*Math.pow(ratio,j));e[e.length-1]=extent;return e;}
      function axis(neg,pos){return side(neg).reverse().map(v=>-v).concat(side(pos));}
      const x=axis(kind==='half'||kind==='strip'?p.L:domain,kind==='strip'?p.L:domain),y=axis(domain,domain),nx=x.length-1,ny=y.length-1;
      const dx=x.slice(1).map((v,i)=>v-x[i]),dy=y.slice(1).map((v,i)=>v-y[i]);
      for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){cap.push(p.phi/100*(p.cr+p.cf)*dx[i]*dy[j]*p.h/p.B);base.push(0);out.push(0);}
      const m=mobility*p.h/p.B;
      for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
        const z=j*nx+i;if(i<nx-1)edge(z,z+1,m*dy[j]/((dx[i]+dx[i+1])/2));if(j<ny-1)edge(z,z+nx,m*dx[i]/((dy[j]+dy[j+1])/2));
        let g=0;if(i===0&&kind==='infinite')g+=m*dy[j]/(dx[i]/2);if(i===nx-1&&kind!=='strip')g+=m*dy[j]/(dx[i]/2);if(j===0||j===ny-1)g+=m*dx[i]/(dy[j]/2);out[z]=g;base[z]+=g;
      }
      well=n*nx+n;const req=.14*Math.hypot(dx[n],dy[n]);wi=1/(C*Math.log(req/p.rw));shape=`${nx} × ${ny} ячеек, декартова сетка`;
    }
    return {cap:Float64Array.from(cap),base:Float64Array.from(base),out:Float64Array.from(out),ei:Int32Array.from(ei),ej:Int32Array.from(ej),eg:Float64Array.from(eg),well,wi,domain,shape};
  }
  function run(p,kind,control,progress=()=>{}){
    validate(p);const g=grid(p,kind),n=g.cap.length,ts=times(p),u=new Float64Array(n),diag=new Float64Array(n),rhs=new Float64Array(n),r=new Float64Array(n),z=new Float64Array(n),v=new Float64Array(n),av=new Float64Array(n);
    const ps=[],qs=[],means=[];let maxResidual=0,maxIterations=0,balance=0,volume=0;
    const delta=p.pi-p.pwf,surplus=control==='pressure'&&kind==='closed';
    // For pressure control evolve p_cell - p_wf directly, avoiding catastrophic
    // cancellation when a closed reservoir approaches equilibrium and q -> 0.
    if(surplus)u.fill(delta);
    // IC(0) Cholesky preconditioner. These radial/orthogonal grids have no triangles.
    const lower=Array.from({length:n},()=>[]),chol=new Float64Array(n);
    for(let e=0;e<g.eg.length;e++)lower[g.ej[e]].push({j:g.ei[e],a:-g.eg[e],v:0});
    function factor(){for(let i=0;i<n;i++){let d=diag[i];for(const e of lower[i]){e.v=e.a/chol[e.j];d-=e.v*e.v;}if(!(d>0))throw Error('Ошибка предобусловливателя.');chol[i]=Math.sqrt(d);}}
    function precondition(){for(let i=0;i<n;i++){let a=r[i];for(const e of lower[i])a-=e.v*z[e.j];z[i]=a/chol[i];}for(let i=n-1;i>=0;i--){z[i]/=chol[i];for(const e of lower[i])z[e.j]-=e.v*z[i];}}
    function mat(x,y){for(let i=0;i<n;i++)y[i]=diag[i]*x[i];for(let e=0;e<g.eg.length;e++){const i=g.ei[e],j=g.ej[e],k=g.eg[e];y[i]-=k*x[j];y[j]-=k*x[i];}}
    const dot=(x,y)=>{let s=0;for(let i=0;i<n;i++)s+=x[i]*y[i];return s;};
    const capacity=g.cap.reduce((a,b)=>a+b,0);
    for(let step=1;step<ts.length;step++){
      const dt=ts[step]-ts[step-1];let before=0;
      for(let i=0;i<n;i++){before+=g.cap[i]*u[i];diag[i]=g.base[i]+g.cap[i]/dt;rhs[i]=g.cap[i]/dt*u[i];}
      if(control==='rate')rhs[g.well]+=p.q;else{diag[g.well]+=g.wi;if(!surplus)rhs[g.well]+=g.wi*delta;}
      factor();mat(u,av);for(let i=0;i<n;i++)r[i]=rhs[i]-av[i];precondition();v.set(z);
      let rz=dot(r,z),bn=Math.sqrt(dot(rhs,rhs)),iter=0,res=Math.sqrt(dot(r,r))/Math.max(bn,1e-30);
      while(res>1e-10&&iter<3000){mat(v,av);const den=dot(v,av);if(!(den>0))throw Error('Нарушена положительная определённость системы.');const a=rz/den;for(let i=0;i<n;i++){u[i]+=a*v[i];r[i]-=a*av[i];}precondition();const next=dot(r,z),b=next/rz;for(let i=0;i<n;i++)v[i]=z[i]+b*v[i];rz=next;res=Math.sqrt(dot(r,r))/Math.max(bn,1e-30);iter++;}
      // Recompute the actual residual, independent of the CG recurrence.
      mat(u,av);let err=0;for(let i=0;i<n;i++)err+=(rhs[i]-av[i])**2;res=Math.sqrt(err)/Math.max(bn,1e-30);
      if(!Number.isFinite(res)||res>1e-7)throw Error('Линейный решатель не сошёлся. Измените сетку или параметры.');
      maxResidual=Math.max(maxResidual,res);maxIterations=Math.max(maxIterations,iter);
      const q=control==='rate'?p.q:g.wi*(surplus?u[g.well]:delta-u[g.well]),pw=control==='rate'?p.pi-u[g.well]-q/g.wi:p.pwf;
      let stored=0,influx=0;for(let i=0;i<n;i++){stored+=g.cap[i]*u[i];influx+=g.out[i]*(surplus?delta-u[i]:u[i]);}
      const loss=surplus?before-stored:stored-before;
      balance+=Math.abs(loss-dt*(q-influx));volume+=Math.abs(q*dt);ps.push(pw);qs.push(q);means.push(surplus?p.pwf+stored/capacity:p.pi-stored/capacity);
      if(step%25===0)progress(step/(ts.length-1));
    }
    return {t:ts.slice(1),p:ps,q:qs,mean:means,mesh:g.shape,cells:n,domain:g.domain,wi:g.wi,maxResidual,maxIterations,balance:balance/Math.max(volume,1e-30),warnings:ps.some(x=>x<=0)?['Забойное давление достигло нуля или стало отрицательным: линейная однофазная модель вне физической области, заданный дебит нельзя поддерживать весь период.']:[]};
  }
  function E1(x){if(x<=0)return Infinity;if(x>740)return 0;if(x<=1){let s=0,term=1;for(let n=1;n<150;n++){term*=-x/n;const a=term/n;s+=a;if(Math.abs(a)<1e-16)break;}return -.5772156649015329-Math.log(x)-s;}let b=x+1,c=1e300,d=1/b,h=d;for(let n=1;n<250;n++){const a=-n*n;b+=2;d=1/(a*d+b);c=b+a/c;const v=c*d;h*=v;if(Math.abs(v-1)<1e-14)break;}return h*Math.exp(-x);}
  function reference(p,kind,t){const {alpha,C}=derived(p);if(kind==='fixed')return {label:'Стационарный предел Дюпюи',p:t.map(()=>p.pi-C*p.q*Math.log(p.R/p.rw)),q:t.map(()=>(p.pi-p.pwf)/(C*Math.log(p.R/p.rw))),late:true};if(kind==='closed'){const V=Math.PI*(p.R*p.R-p.rw*p.rw)*p.h*p.phi/100;return {label:'Поздний псевдоустановившийся режим',p:t.map(x=>p.pi-p.q*p.B*x/(V*(p.cr+p.cf))-C*p.q*(Math.log(p.R/p.rw)-.75)),q:null,late:true};}
    const kernel=t=>{let a=.5*E1(p.rw**2/(4*alpha*t));if(kind==='half')a+=.5*E1(p.L*p.L/(alpha*t));if(kind==='strip'){for(let n=1;n<=20000;n++){const v=E1(n*n*p.L*p.L/(alpha*t));a+=v;if(v<1e-13)break;if(n===20000)throw Error('Слишком большое число зеркальных скважин. Увеличьте L или уменьшите период.');}}return a;};
    // Product integration: piecewise-constant rate changes solve the Volterra relation.
    const nodes=[0];const t0=Math.max(1e-5,100*p.rw*p.rw/alpha);if(t0>=p.days)return {label: 'Линейный сток вне области сравнения на этом интервале',p:t.map(()=>null),q:null,late:false};for(let i=0;i<=650;i++)nodes.push(t0*Math.pow(p.days/t0,i/650));const dq=[],rates=[];let sum=0;
    for(let i=1;i<nodes.length;i++){let history=0;for(let j=1;j<i;j++)history+=dq[j-1]*kernel(nodes[i]-nodes[j-1]);const change=((p.pi-p.pwf)/C-history)/kernel(nodes[i]-nodes[i-1]);dq.push(change);sum+=change;rates.push(sum);}
    function interp(x){let j=1;while(j<nodes.length-1&&nodes[j]<x)j++;const a=(x-nodes[j-1])/(nodes[j]-nodes[j-1]);return rates[Math.max(0,j-2)]*(1-a)+rates[j-1]*a;}
    return {label:'Линейный сток'+(kind==='infinite'?'':' и метод изображений'),p:t.map(x=>p.pi-C*p.q*kernel(x)),q:t.map(x=>x<t0?null:interp(x)),late:false};
  }
  return {defaults,names,validate,derived,grid,run,reference,E1};
}
if(typeof module!=='undefined')module.exports=createSimulator;
