from pathlib import Path
import base64
root=Path(__file__).resolve().parent
template=(root/'src/index.template.html').read_text(encoding='utf8')
for marker,name in [('STYLE','style.css'),('SOLVER','solver.js'),('APP','app.js')]:
    template=template.replace('/*'+marker+'*/',(root/'src'/name).read_text(encoding='utf8'))
emblem=root/'src/gubkin-emblem.png'
template=template.replace('/*EMBLEM*/','data:image/png;base64,'+base64.b64encode(emblem.read_bytes()).decode())
(root/'index.html').write_text(template,encoding='utf8')
print(root/'index.html')
