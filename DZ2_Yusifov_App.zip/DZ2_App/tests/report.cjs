// Programmatic integration check of worker, report and SVG generation.
// This is not a visual browser test.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),elements=new Map(),handlers={};
function element(id){if(!elements.has(id))elements.set(id,{innerHTML:'',textContent:'',hidden:false,disabled:false,checked:id==='#log',value:'',dataset:{},classList:{add(){},remove(){},toggle(){}},addEventListener(type,fn){handlers[id+':'+type]=fn;},setAttribute(){}});return elements.get(id);}
const sim=require('../src/solver.js')();
element('#parameters').elements=Object.entries(sim.defaults).map(([name,value])=>({name,value:String(value)}));
for(const e of element('#parameters').elements)element('#parameters').elements[e.name]=e;
element('style').textContent=fs.readFileSync(path.join(root,'src/style.css'),'utf8');
const context=vm.createContext({console,performance,Blob,URL,setTimeout,document:{querySelector:element,querySelectorAll:()=>[]},Worker:class{constructor(url){this.url=url;}terminate(){}postMessage(data){const source=context.api.workerText(),w=vm.createContext({postMessage:d=>this.onmessage({data:d})});vm.runInContext(source,w);w.onmessage({data});}}});
vm.runInContext(fs.readFileSync(path.join(root,'src/solver.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'src/app.js'),'utf8')+`;globalThis.api={start,report,render,workerText,markStale,setParams,getBatch:()=>batch,select:(k,m)=>{selected=k;mode=m;render();},getStale:()=>stale};download=(name,data,type)=>{globalThis.captured={name,data,type};};`,context);
context.api.start();assert(context.api.getBatch(),'Calculation failed: '+element('#status').textContent);
for(const k of Object.keys(sim.names))for(const m of ['rate','pressure']){context.api.select(k,m);assert(element('#charts').innerHTML.includes('<svg'));assert(!element('#charts').innerHTML.includes('NaN'));assert(element('#explanation').innerHTML.length>150);}
context.api.report();assert.equal(context.captured.name,'DZ2_Yusifov_report.html');
assert.equal((context.captured.data.match(/<svg /g)||[]).length,25);assert(!/NaN|Infinity/.test(context.captured.data));
assert(context.captured.data.includes('Юсифов Р.Р.'));assert(context.captured.data.includes('renat2004yusifov@gmail.com'));
assert(!/<(?:script|link)[^>]+(?:src|href)=/.test(context.captured.data));
fs.writeFileSync(path.join(root,'DZ2_example_report.html'),context.captured.data);
fs.writeFileSync(path.join(__dirname,'example-results.json'),JSON.stringify(context.api.getBatch(),null,2));
context.api.setParams({...sim.defaults,k:100});assert(context.api.getStale());assert(element('#export').disabled);
console.log('PASS: all 10 simulations, 20 plots, 5 schemes, report export, changed-parameter invalidation. Browser layout not tested.');
