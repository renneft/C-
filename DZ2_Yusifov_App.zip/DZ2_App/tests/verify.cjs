// Run with Node.js: node tests/verify.cjs (no packages required).
const assert=require('node:assert/strict');
const fs=require('node:fs');
const sim=require('../src/solver.js')();
const p={...sim.defaults},audit=[];
function rel(a,b){return Math.abs(a-b)/Math.max(1e-10,Math.abs(b));}
function finite(a){assert(a.every(Number.isFinite));}
assert(Math.abs(sim.E1(1)-.2193839343955203)<1e-13);
assert(Math.abs(sim.E1(2)-.04890051070806112)<1e-13);
assert.throws(()=>sim.validate({...p,cf:-1}));
assert.throws(()=>sim.validate({...p,L:.01}));
assert.throws(()=>sim.validate({...p,pwf:150}));
for(const kind of Object.keys(sim.names)){
  const coarse=sim.run({...p,quality:0},kind,'rate'),a=sim.run(p,kind,'rate'),b=sim.run(p,kind,'pressure');
  const fine=sim.run({...p,quality:2},kind,'rate'),bf=sim.run({...p,quality:2},kind,'pressure'),ref=sim.reference(p,kind,a.t);
  for(const r of [coarse,a,b,fine,bf]){finite(r.p);finite(r.q);assert(r.balance<1e-6);assert(r.maxResidual<1e-7);}
  assert(a.q.every(q=>q===p.q));assert(b.p.every(v=>v===p.pwf));
  assert(a.p.every((x,i)=>i===0||x<=a.p[i-1]+1e-5));
  assert(b.q.every((x,i)=>i===0||x<=b.q[i-1]+1e-4));
  const e1=Math.abs(coarse.p.at(-1)-ref.p.at(-1)),e2=Math.abs(a.p.at(-1)-ref.p.at(-1)),e3=Math.abs(fine.p.at(-1)-ref.p.at(-1));
  if(kind==='closed'||kind==='fixed')assert(e2<1e-4);else assert(e2<.1);
  if(['infinite','half','strip'].includes(kind)){assert(e3<e2);assert(e2<e1);}
  if(ref.q){assert(rel(b.q.at(-1),ref.q.at(-1))<.01);finite(ref.q.filter(x=>x!==null));}
  audit.push({kind,cells:a.cells,pressure:a.p.at(-1),rate:b.q.at(-1),referencePressure:ref.p.at(-1),referenceRate:ref.q?.at(-1),coarsePressureError:e1,standardPressureError:e2,finePressureError:e3,pressureChangeOnRefinement:Math.abs(a.p.at(-1)-fine.p.at(-1)),rateChangeOnRefinement:Math.abs(b.q.at(-1)-bf.q.at(-1)),balance:a.balance,maxResidual:a.maxResidual});
  console.log(kind,'PASS',JSON.stringify(audit.at(-1)));
  if(kind==='closed'){
    const cap=p.phi/100*(p.cr+p.cf)*Math.PI*(p.R*p.R-p.rw*p.rw)*p.h/p.B;
    assert(Math.abs(a.mean.at(-1)-(p.pi-p.q*p.days/cap))<1e-5);
  }
}
const base=sim.run(p,'fixed','rate').p.at(-1),doubleK=sim.run({...p,k:p.k*2},'fixed','rate').p.at(-1);
assert(rel(p.pi-doubleK,(p.pi-base)/2)<1e-6);
const baseQ=sim.run(p,'fixed','pressure').q.at(-1),doubleH=sim.run({...p,h:p.h*2},'fixed','pressure').q.at(-1);
assert(rel(doubleH,baseQ*2)<1e-6);
const warn=sim.run({...p,q:500},'closed','rate');assert(warn.warnings.length>0);
const changed=sim.run({...p,cf:.0001,days:30,L:500,k:100,phi:20},'strip','rate');finite(changed.p);assert(changed.balance<1e-6);
fs.writeFileSync(require('node:path').join(__dirname,'validation.json'),JSON.stringify({date:new Date().toISOString(),parameters:p,tests:'PASS',audit},null,2));
console.log('All tests passed.');
